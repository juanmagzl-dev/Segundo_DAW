# Pedir el nombre al usuario
nombre = input("Por favor, introduzca su nombre: ")

# Mostrar los mensajes con el nombre introducido
print(f"¡Hola {nombre}!")
print(f"Me alegro de conocerle, {nombre}")

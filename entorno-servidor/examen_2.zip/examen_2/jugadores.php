<?php
requiere_once "iCliente.php"
$jugadores = [
    ["nombre"=>"juan","edad"=>18, "dni"=>"285767c"],
    ["nombre" => "María","edad"=>17, "dni" => "192945f"],
    ["nombre" => "Pedro","edad"=>19, "dni" => "242945f"],
    ["nombre" => "Antonio","edad"=>20, "dni" => "302945f"]
]

?>
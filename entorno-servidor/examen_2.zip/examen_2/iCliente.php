<?php

interface iCliente{
    public function listarClientes();
    public function aforo();
    public function ordenarDNI();
}

?>
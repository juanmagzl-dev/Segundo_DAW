<?php

requiere_once "iCliente.php";
require_once "jugador.php";
require_once "dados.php";

// listar a los clientes
echo "<h2>Listado inicial de clientes:</h2>";
$casino->listarClientes();

// crear jugadores
echo "<h2>Creando nuevos jugadores:</h2>";


?>